
					<!-- end:: Footer -->
				</div>
			</div>
		</div>

		<!-- end:: Page -->

	

		<!-- begin::Scrolltop -->
		<div id="kt_scrolltop" class="kt-scrolltop">
			<i class="fa fa-arrow-up"></i>
		</div>

		<!-- end::Scrolltop -->


		<!-- end::Sticky Toolbar -->


	</body>

	<!-- end::Body -->
</html>